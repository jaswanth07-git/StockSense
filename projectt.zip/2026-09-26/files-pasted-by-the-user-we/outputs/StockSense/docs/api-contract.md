# StockSense API contract

All endpoints use JSON and the `/api` prefix. Signup/login/reset are public. Other API routes require `Authorization: Bearer <token>`. IDs are opaque strings; timestamps are ISO-8601. Errors use `{ "error": { "code": "...", "message": "..." } }`.

## Routes

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/signup` | `{name,email,password}`; creates an account and returns `{token,user}` |
| POST | `/auth/login` | `{email,password}`; returns `{token,user}` |
| POST | `/auth/password-reset/request` | `{email}`; development mode returns `developmentOtp` in response |
| POST | `/auth/password-reset/confirm` | `{email,otp,newPassword}` |
| POST | `/auth/logout` | Invalidates current process session |
| GET/PATCH | `/profile` | Read/update the signed-in user's name |
| GET/POST | `/products` | Search with `search`, `category`, `locationId`, or `stock=low|out`; create with `name,sku,category,unit,reorderPoint,initialStock,locationId` |
| PATCH/DELETE | `/products/:id` | Update product or archive it |
| GET | `/categories` | List categories |
| POST | `/categories` | Add `{name}` |
| GET/POST | `/warehouses` | List or create `{name,code,address}` locations |
| PATCH | `/warehouses/:id` | Update a location |
| GET/POST | `/documents` | Filter documents or create `{type,sourceId,destinationId,partner,lines:[{productId,quantity,countedQuantity?}]}` |
| PATCH | `/documents/:id` | Update draft/waiting/ready document fields |
| POST | `/documents/:id/transition` | `{state:"Waiting"|"Ready"|"Done"|"Canceled"}` |
| GET | `/ledger` | Filter by `search`, `locationId`, and `type` |
| GET | `/dashboard` | KPIs, low-stock list, and 7-day receipt/delivery movement totals; optional `locationId` |
| GET | `/alerts/low-stock` | Low/out-of-stock products |

Operation types are `Receipt`, `Delivery`, `Internal`, and `Adjustment`. Valid state transitions are Draft→Waiting/Ready/Canceled, Waiting→Ready/Canceled, Ready→Waiting/Done/Canceled. Only transition to Done posts stock. Repeated validation is rejected. A receipt increments destination stock; a delivery requires sufficient source stock; a transfer decrements source and increments destination; an adjustment sets the counted stock and records the difference. A movement entry is created per affected product/location. Document validation and JSON state save are process-local; MySQL transactions are not implemented yet.

Product list responses include `totalStock` and `stockByLocation`. Documents include resolved source/destination and product labels. Dashboard fields include `totalUnits`, `productCount`, `lowStockCount`, `outOfStockCount`, `pendingReceipts`, `pendingDeliveries`, `scheduledTransfers`, `lowStockItems`, and `movementTrend`.

## Storage and security notes

Current persistence is a JSON file, not MySQL. Local passwords use PBKDF2 with per-user random salts. Sessions and OTPs are process-local and expire; restart clears sessions/reset codes. OTP delivery is only simulated in development. Configure email/SMS delivery and durable session/reset storage before production.
