# StockSense architecture, ownership, and integration

## Inspected starter and requirements

The supplied PDF requires authentication and OTP reset; dashboard KPIs and filters; products, categories, reorder rules, and stock by location; receipts; deliveries; transfers; adjustments; movement history; low-stock alerts; SKU search; and multiple warehouses. Required document states are Draft, Waiting, Ready, Done, and Canceled.

The supplied ZIP contains a minimal Express 5 root health endpoint, root package metadata with `mysql2`, and an almost empty backend package. It had no frontend, database schema, database connection, or existing inventory modules. The application keeps Express and provides a same-origin browser interface. It uses JSON-file persistence so the project is immediately runnable; a real MySQL persistence adapter remains to be implemented and reviewed before multi-user/production use.

## Architecture and contracts

- `backend/src/app.js`: REST routes, validation, business rules, and static app serving.
- `backend/src/store.js`: seeded local inventory and atomic-file persistence. Location stock is keyed by product/location.
- `backend/src/security.js`: password hashing, process-local bearer sessions, auth middleware, and development reset codes.
- `public/`: responsive dashboard and feature interface, using the same-origin REST API.
- `docs/api-contract.md`: routes, request conventions, states, and movement semantics.

Product master data is separate from location balances. Receipt validation increases destination stock. Delivery validation checks available stock before decrementing. Transfers write equal and opposite location movements. Adjustments set the counted quantity and ledger the difference. Completed/canceled documents cannot be edited; each validation is applied once.

## Exclusive ownership map

| Teammate | Owns | Responsibility |
|---|---|---|
| Rohith | `backend/src/app.js`, `backend/src/security.js`, `backend/src/store.js`, root `server.js` | Sole owner of current backend integration entry points, auth/profile/products, server wiring, and route mounting |
| Rishitha | `public/index.html`, `public/styles.css`, new `public/features/dashboard.js`, `public/features/products.js` | App shell, styles, dashboard/product feature modules. Submit integration requests for the existing `public/app.js`; do not edit it directly. |
| Jaswanth | New `backend/src/modules/operations/`, `backend/src/modules/ledger/`, new `public/features/operations.js` | Receipts, deliveries, transfers, adjustments, movement history. Deliver isolated routers/modules for Rohith to mount; do not edit `backend/src/app.js` or `public/app.js`. |
| Koushik | New `backend/src/modules/warehouses/`, new `public/features/warehouses.js`, `public/features/settings.js`, all `docs/`, root `README.md`, `.env.example` | Warehouse/location management, setup and API documentation. Deliver isolated modules for Rohith to mount; do not edit shared entry files. |

The first integrated draft keeps feature handlers in `backend/src/app.js` and `public/app.js`; these entry files now have a single owner (Rohith). New teammate work should go into the exclusive module paths in the map. Rohith owns mounting/integration in the shared entry points. This current workspace has not contacted the four teammates.

## Integration order

1. Confirm and refine the starter-compatible API/data contract in `docs/api-contract.md`.
2. Agree the MySQL schema and transactional repository interface; migrate the JSON demo store without changing API payloads.
3. Have feature owners implement extensions only in their exclusive new module paths and use the API contract for integration.
4. Rohith mounts isolated routers/modules in the shared app files after reviewing them; do not have multiple contributors edit those files.
5. Integrate location and product APIs before operations, then validate ledger and dashboard consistency.
6. Check setup from a clean install and confirm each screen uses the live API.

## Known follow-up

MySQL connection/migrations/transactions and email/SMS OTP delivery are not implemented. Sessions/reset codes are memory-only. The interface creates one product line per document; the backend accepts multiple lines. Dashboard date range is a seven-day view; operation filters support type, state, location, and category. Confirm database and auth expectations with the course team before production deployment.
