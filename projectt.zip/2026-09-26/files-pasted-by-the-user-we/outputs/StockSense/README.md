# StockSense

A modular inventory management system starter with an Express API and a responsive browser app.

## Run locally

Requirements: Node.js 18 or later and npm.

1. From this directory, run `npm install`.
2. Copy `.env.example` to `.env` and adjust the settings if needed.
3. Run `npm run dev` for development or `npm start` for a normal run.
4. Open `http://localhost:5000` and create an account.

The app writes local data to `backend/data/stocksense.json` by default. Set `DATA_FILE` to use another location. The starter ZIP included `mysql2` as a dependency, but did not include a database schema, connection configuration, or MySQL server. This implementation therefore uses local JSON persistence so the app runs without a database service. A MySQL adapter and production deployment configuration remain follow-up integration work; do not treat the listed dependency as an active connection.

The first run seeds demo inventory and sample operations. Delete the generated JSON file to reset the demo. The OTP password reset route returns the code in the response only when `NODE_ENV` is not `production`; production delivery requires an email/SMS provider and `NODE_ENV=production` suppresses the code.

## Features

- Signup, login, protected API, profile editing, logout, and development OTP password reset.
- Dashboard KPIs, warehouse filter, live stock movement chart, recent operations, and reorder watch.
- Product catalog with SKU search, category/location/stock filters, per-location balances, reorder points, and CSV export.
- Warehouse/location setup and stock breakdown.
- Receipt, delivery, internal transfer, and adjustment documents with Draft, Waiting, Ready, Done, and Canceled states.
- Validation updates stock and appends movement history; deliveries/transfers reject insufficient stock.
- Filterable ledger and low-stock API.

## API overview

See [`docs/api-contract.md`](docs/api-contract.md) for request shapes. Main groups include `/api/auth`, `/api/profile`, `/api/products`, `/api/warehouses`, `/api/documents`, `/api/ledger`, `/api/dashboard`, and `/api/alerts/low-stock`. Authenticated routes accept a bearer token. API errors follow `{ "error": { "code", "message" } }`.

## Environment

See `.env.example`. Never commit real credentials. The current JSON storage mode needs no database credentials.

## Team ownership and integration

See [`docs/team-plan.md`](docs/team-plan.md) for the four-person exclusive file ownership map and integration sequence. The student team should agree on and implement a MySQL persistence adapter before relying on concurrent or production use: JSON file storage is intended for local review/demo use.
