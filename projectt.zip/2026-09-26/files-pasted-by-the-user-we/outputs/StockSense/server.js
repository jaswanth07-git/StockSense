require('dotenv').config();
const app = require('./backend/src/app');
const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`StockSense is ready at http://localhost:${port}`));
