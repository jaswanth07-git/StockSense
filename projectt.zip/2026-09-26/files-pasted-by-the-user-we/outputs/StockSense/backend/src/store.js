const fs = require('node:fs');
const path = require('node:path');

const dataPath = process.env.DATA_FILE || path.join(__dirname, '..', 'data', 'stocksense.json');
const seed = () => ({
  users: [],
  categories: ['Raw Materials', 'Finished Goods', 'Packaging'],
  warehouses: [
    { id: 'wh-main', name: 'Main Warehouse', code: 'MAIN', address: 'North District', active: true },
    { id: 'wh-prod', name: 'Production Floor', code: 'PROD', address: 'Building 2', active: true },
  ],
  products: [
    { id: 'p-steel', name: 'Steel Rods', sku: 'STL-001', category: 'Raw Materials', unit: 'kg', reorderPoint: 30, active: true },
    { id: 'p-chair', name: 'Oak Chair', sku: 'CHR-014', category: 'Finished Goods', unit: 'pcs', reorderPoint: 12, active: true },
    { id: 'p-box', name: 'Shipping Box', sku: 'PKG-020', category: 'Packaging', unit: 'pcs', reorderPoint: 50, active: true },
    { id: 'p-frame', name: 'Steel Frame', sku: 'FRM-008', category: 'Finished Goods', unit: 'pcs', reorderPoint: 10, active: true },
  ],
  balances: { 'p-steel|wh-main': 240, 'p-steel|wh-prod': 18, 'p-chair|wh-main': 8, 'p-box|wh-main': 120, 'p-frame|wh-prod': 32 },
  documents: [
    { id: 'doc-1001', number: 'REC-1001', type: 'Receipt', state: 'Waiting', partner: 'Apex Metals', sourceId: null, destinationId: 'wh-main', createdAt: new Date().toISOString(), lines: [{ productId: 'p-steel', quantity: 60 }] },
    { id: 'doc-1002', number: 'DEL-1002', type: 'Delivery', state: 'Ready', partner: 'Northstar Retail', sourceId: 'wh-prod', destinationId: null, createdAt: new Date().toISOString(), lines: [{ productId: 'p-frame', quantity: 6 }] },
    { id: 'doc-1003', number: 'TRF-1003', type: 'Internal', state: 'Ready', partner: '', sourceId: 'wh-main', destinationId: 'wh-prod', createdAt: new Date().toISOString(), lines: [{ productId: 'p-steel', quantity: 15 }] },
    { id: 'doc-1004', number: 'ADJ-1004', type: 'Adjustment', state: 'Draft', partner: '', sourceId: 'wh-main', destinationId: null, createdAt: new Date().toISOString(), lines: [{ productId: 'p-box', quantity: 2, countedQuantity: 118 }] },
  ],
  ledger: [
    { id: 'mov-1', date: new Date(Date.now() - 3600000).toISOString(), type: 'Receipt', reference: 'REC-0998', productId: 'p-steel', locationId: 'wh-main', delta: 200, user: 'System' },
    { id: 'mov-2', date: new Date(Date.now() - 1800000).toISOString(), type: 'Internal', reference: 'TRF-0999', productId: 'p-steel', locationId: 'wh-prod', delta: 18, user: 'System' },
  ],
});

function load() {
  try { return JSON.parse(fs.readFileSync(dataPath, 'utf8')); }
  catch { const state = seed(); save(state); return state; }
}
function save(state) {
  fs.mkdirSync(path.dirname(dataPath), { recursive: true });
  const temp = `${dataPath}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2));
  fs.renameSync(temp, dataPath);
}
const state = load();
module.exports = { state, save };
