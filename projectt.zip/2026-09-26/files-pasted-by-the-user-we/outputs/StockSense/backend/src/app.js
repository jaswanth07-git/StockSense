const express = require('express');
const crypto = require('node:crypto');
const path = require('node:path');
const { state, save } = require('./store');
const { hash, makeToken, auth, resets, sessions } = require('./security');

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', '..', 'public')));
const id = (prefix) => `${prefix}-${crypto.randomBytes(5).toString('hex')}`;
const fail = (res, status, code, message) => res.status(status).json({ error: { code, message } });
const totalFor = (productId) => Object.entries(state.balances).filter(([key]) => key.startsWith(`${productId}|`)).reduce((sum, [, qty]) => sum + Number(qty), 0);
const productById = (productId) => state.products.find((product) => product.id === productId);
const warehouseById = (warehouseId) => state.warehouses.find((warehouse) => warehouse.id === warehouseId);
const nextNumber = (type) => `${({ Receipt: 'REC', Delivery: 'DEL', Internal: 'TRF', Adjustment: 'ADJ' })[type]}-${Date.now().toString().slice(-6)}`;

app.get('/api/health', (_req, res) => res.json({ status: 'ok', storage: 'local-json' }));
app.post('/api/auth/signup', (req, res) => {
  const name = String(req.body.name || '').trim(); const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8) return fail(res, 400, 'INVALID_INPUT', 'Enter a name, valid email, and password with at least 8 characters.');
  if (state.users.some((user) => user.email === email)) return fail(res, 409, 'EMAIL_EXISTS', 'An account already exists for this email.');
  const credentials = hash(password); const user = { id: id('usr'), name, email, ...credentials, role: 'Manager' };
  state.users.push(user); save(state); res.status(201).json({ token: makeToken(user), user: { id: user.id, name, email, role: user.role } });
});
app.post('/api/auth/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  const user = state.users.find((entry) => entry.email === email); const attempt = user && hash(password, user.salt).digest;
  if (!user || !crypto.timingSafeEqual(Buffer.from(attempt, 'hex'), Buffer.from(user.digest, 'hex'))) return fail(res, 401, 'INVALID_CREDENTIALS', 'Email or password is incorrect.');
  res.json({ token: makeToken(user), user: { id: user.id, name: user.name, email, role: user.role } });
});
app.post('/api/auth/password-reset/request', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!state.users.some((user) => user.email === email)) return res.json({ message: 'If the account exists, a reset code has been issued.' });
  const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); resets.set(email, { otp, expiresAt: Date.now() + 10 * 60 * 1000 });
  const result = { message: 'A development reset code is ready. It expires in 10 minutes.' };
  if (process.env.NODE_ENV !== 'production') result.developmentOtp = otp;
  res.json(result);
});
app.post('/api/auth/password-reset/confirm', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const entry = resets.get(email);
  if (!entry || entry.expiresAt < Date.now() || entry.otp !== String(req.body.otp || '')) return fail(res, 400, 'INVALID_OTP', 'The code is invalid or expired. Request a new one.');
  const user = state.users.find((row) => row.email === email); const newPassword = String(req.body.newPassword || '');
  if (!user || newPassword.length < 8) return fail(res, 400, 'INVALID_INPUT', 'New password must be at least 8 characters.');
  const credentials = hash(newPassword);
  Object.assign(user, credentials); resets.delete(email); save(state); res.json({ message: 'Password updated. You can now sign in.' });
});
app.use('/api', (req, res, next) => req.path.startsWith('/auth/') ? next() : auth(req, res, next));
app.get('/api/profile', (req, res) => res.json({ id: req.user.id, name: req.user.name, email: req.user.email, role: req.user.role }));
app.patch('/api/profile', (req, res) => { req.user.name = String(req.body.name || req.user.name).trim(); save(state); res.json({ id: req.user.id, name: req.user.name, email: req.user.email, role: req.user.role }); });
app.post('/api/auth/logout', (req, res) => { const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''); sessions.delete(token); res.json({ message: 'Signed out.' }); });

app.get('/api/categories', (_req, res) => res.json({ data: state.categories }));
app.post('/api/categories', (req, res) => { const name = String(req.body.name || '').trim(); if (!name) return fail(res, 400, 'INVALID_INPUT', 'Category name is required.'); if (!state.categories.includes(name)) state.categories.push(name); save(state); res.status(201).json({ name }); });
app.get('/api/products', (req, res) => {
  const { search = '', category = '', locationId = '', stock = '' } = req.query; const q = String(search).toLowerCase();
  const quantity = (productId) => locationId ? Number(state.balances[`${productId}|${locationId}`] || 0) : totalFor(productId);
  let rows = state.products.filter((p) => (!q || `${p.name} ${p.sku}`.toLowerCase().includes(q)) && (!category || p.category === category));
  if (stock) rows = rows.filter((p) => stock === 'low' ? quantity(p.id) <= p.reorderPoint : quantity(p.id) === 0);
  res.json({ data: rows.map((p) => ({ ...p, totalStock: quantity(p.id), stockByLocation: state.warehouses.map((w) => ({ locationId: w.id, location: w.name, quantity: Number(state.balances[`${p.id}|${w.id}`] || 0) })).filter((row) => !locationId || row.locationId === locationId) })) });
});
app.post('/api/products', (req, res) => {
  const { name, sku, category, unit, reorderPoint = 0, initialStock = 0, locationId } = req.body;
  if (!String(name || '').trim() || !String(sku || '').trim() || !category || !unit) return fail(res, 400, 'INVALID_INPUT', 'Name, SKU, category, and unit are required.');
  if (state.products.some((p) => p.sku.toLowerCase() === String(sku).trim().toLowerCase())) return fail(res, 409, 'SKU_EXISTS', 'That SKU is already in use.');
  const product = { id: id('prd'), name: String(name).trim(), sku: String(sku).trim(), category, unit, reorderPoint: Math.max(0, Number(reorderPoint) || 0), active: true };
  state.products.push(product);
  if (Number(initialStock) > 0) { const location = locationId || state.warehouses[0]?.id; if (!location || !warehouseById(location)) return fail(res, 400, 'INVALID_LOCATION', 'Choose a valid location for initial stock.'); state.balances[`${product.id}|${location}`] = Number(initialStock); state.ledger.push({ id: id('mov'), date: new Date().toISOString(), type: 'Adjustment', reference: 'INITIAL', productId: product.id, locationId: location, delta: Number(initialStock), user: req.user.name }); }
  save(state); res.status(201).json(product);
});
app.patch('/api/products/:id', (req, res) => { const product = productById(req.params.id); if (!product) return fail(res, 404, 'NOT_FOUND', 'Product not found.'); const sku = String(req.body.sku ?? product.sku).trim(); if (state.products.some((p) => p.id !== product.id && p.sku.toLowerCase() === sku.toLowerCase())) return fail(res, 409, 'SKU_EXISTS', 'That SKU is already in use.'); for (const key of ['name', 'sku', 'category', 'unit']) if (req.body[key] !== undefined) product[key] = String(req.body[key]).trim(); if (req.body.reorderPoint !== undefined) product.reorderPoint = Math.max(0, Number(req.body.reorderPoint) || 0); save(state); res.json(product); });
app.delete('/api/products/:id', (req, res) => { const p = productById(req.params.id); if (!p) return fail(res, 404, 'NOT_FOUND', 'Product not found.'); p.active = false; save(state); res.json({ message: 'Product archived.' }); });

app.get('/api/warehouses', (_req, res) => res.json({ data: state.warehouses }));
app.post('/api/warehouses', (req, res) => { const name = String(req.body.name || '').trim(); const code = String(req.body.code || '').trim().toUpperCase(); if (!name || !code) return fail(res, 400, 'INVALID_INPUT', 'Name and code are required.'); if (state.warehouses.some((w) => w.code === code)) return fail(res, 409, 'CODE_EXISTS', 'Location code already exists.'); const row = { id: id('loc'), name, code, address: String(req.body.address || ''), active: true }; state.warehouses.push(row); save(state); res.status(201).json(row); });
app.patch('/api/warehouses/:id', (req, res) => { const row = warehouseById(req.params.id); if (!row) return fail(res, 404, 'NOT_FOUND', 'Location not found.'); for (const key of ['name', 'code', 'address', 'active']) if (req.body[key] !== undefined) row[key] = req.body[key]; save(state); res.json(row); });

app.get('/api/documents', (req, res) => { const { type, state: status, locationId, category, search } = req.query; let rows = state.documents.filter((d) => (!type || d.type === type) && (!status || d.state === status) && (!locationId || d.sourceId === locationId || d.destinationId === locationId) && (!search || `${d.number} ${d.partner}`.toLowerCase().includes(String(search).toLowerCase()))); if (category) rows = rows.filter((d) => d.lines.some((line) => productById(line.productId)?.category === category)); res.json({ data: rows.map((d) => ({ ...d, source: warehouseById(d.sourceId)?.name || '', destination: warehouseById(d.destinationId)?.name || '', lines: d.lines.map((line) => ({ ...line, product: productById(line.productId)?.name || 'Archived product', sku: productById(line.productId)?.sku || '' })) })) }); });
app.post('/api/documents', (req, res) => {
  const { type, sourceId = null, destinationId = null, partner = '', lines = [] } = req.body;
  if (!['Receipt', 'Delivery', 'Internal', 'Adjustment'].includes(type)) return fail(res, 400, 'INVALID_TYPE', 'Choose a supported document type.');
  if (!Array.isArray(lines) || !lines.length || lines.some((l) => !productById(l.productId) || !Number.isFinite(Number(l.quantity)) || Number(l.quantity) <= 0)) return fail(res, 400, 'INVALID_LINES', 'Add products with quantities greater than zero.');
  if ((type === 'Receipt' && !warehouseById(destinationId)) || ((type === 'Delivery' || type === 'Adjustment') && !warehouseById(sourceId)) || (type === 'Internal' && (!warehouseById(sourceId) || !warehouseById(destinationId) || sourceId === destinationId))) return fail(res, 400, 'INVALID_LOCATION', 'Choose valid source and destination locations.');
  const document = { id: id('doc'), number: nextNumber(type), type, state: 'Draft', partner: String(partner), sourceId, destinationId, createdAt: new Date().toISOString(), lines: lines.map((l) => ({ productId: l.productId, quantity: Number(l.quantity), ...(type === 'Adjustment' ? { countedQuantity: Number(l.countedQuantity ?? l.quantity) } : {}) })) };
  state.documents.unshift(document); save(state); res.status(201).json(document);
});
app.patch('/api/documents/:id', (req, res) => { const d = state.documents.find((doc) => doc.id === req.params.id); if (!d) return fail(res, 404, 'NOT_FOUND', 'Document not found.'); if (d.state === 'Done' || d.state === 'Canceled') return fail(res, 409, 'IMMUTABLE_DOCUMENT', 'Completed or canceled documents cannot be changed.'); if (req.body.partner !== undefined) d.partner = String(req.body.partner); if (req.body.lines) { if (!Array.isArray(req.body.lines) || !req.body.lines.length || req.body.lines.some((l) => !productById(l.productId) || Number(l.quantity) <= 0)) return fail(res, 400, 'INVALID_LINES', 'Add products with quantities greater than zero.'); d.lines = req.body.lines.map((l) => ({ productId: l.productId, quantity: Number(l.quantity), ...(d.type === 'Adjustment' ? { countedQuantity: Number(l.countedQuantity ?? l.quantity) } : {}) })); } save(state); res.json(d); });
app.post('/api/documents/:id/transition', (req, res) => {
  const d = state.documents.find((doc) => doc.id === req.params.id); if (!d) return fail(res, 404, 'NOT_FOUND', 'Document not found.'); const next = req.body.state;
  const allowed = { Draft: ['Waiting', 'Ready', 'Canceled'], Waiting: ['Ready', 'Canceled'], Ready: ['Waiting', 'Done', 'Canceled'] };
  if (!allowed[d.state]?.includes(next)) return fail(res, 409, 'INVALID_TRANSITION', `Cannot move ${d.state} to ${next}.`);
  if (next === 'Done') {
    for (const line of d.lines) {
      const key = `${line.productId}|${d.sourceId}`; const requested = d.type === 'Adjustment' ? Number(line.countedQuantity) : line.quantity;
      if (d.type !== 'Receipt' && (requested < 0 || (d.type !== 'Adjustment' && Number(state.balances[key] || 0) < requested))) return fail(res, 409, 'INSUFFICIENT_STOCK', `Not enough ${productById(line.productId)?.name || 'product'} at the source location.`);
      if (d.type === 'Adjustment' && requested < 0) return fail(res, 400, 'INVALID_COUNT', 'Counted quantity cannot be negative.');
    }
    for (const line of d.lines) {
      const sourceKey = `${line.productId}|${d.sourceId}`; const destKey = `${line.productId}|${d.destinationId}`; let changes = [];
      if (d.type === 'Receipt') { state.balances[destKey] = Number(state.balances[destKey] || 0) + line.quantity; changes = [[d.destinationId, line.quantity]]; }
      if (d.type === 'Delivery') { state.balances[sourceKey] = Number(state.balances[sourceKey] || 0) - line.quantity; changes = [[d.sourceId, -line.quantity]]; }
      if (d.type === 'Internal') { state.balances[sourceKey] = Number(state.balances[sourceKey] || 0) - line.quantity; state.balances[destKey] = Number(state.balances[destKey] || 0) + line.quantity; changes = [[d.sourceId, -line.quantity], [d.destinationId, line.quantity]]; }
      if (d.type === 'Adjustment') { const before = Number(state.balances[sourceKey] || 0); const delta = Number(line.countedQuantity) - before; state.balances[sourceKey] = Number(line.countedQuantity); changes = [[d.sourceId, delta]]; }
      for (const [locationId, delta] of changes) if (delta !== 0) state.ledger.unshift({ id: id('mov'), date: new Date().toISOString(), type: d.type, reference: d.number, productId: line.productId, locationId, delta, user: req.user.name });
    }
  }
  d.state = next; d.updatedAt = new Date().toISOString(); save(state); res.json(d);
});

app.get('/api/ledger', (req, res) => { const { search = '', locationId = '', type = '' } = req.query; const q = String(search).toLowerCase(); const data = state.ledger.filter((m) => (!locationId || m.locationId === locationId) && (!type || m.type === type) && (!q || `${m.reference} ${productById(m.productId)?.name} ${productById(m.productId)?.sku}`.toLowerCase().includes(q))).map((m) => ({ ...m, product: productById(m.productId)?.name, sku: productById(m.productId)?.sku, location: warehouseById(m.locationId)?.name })); res.json({ data }); });
app.get('/api/dashboard', (req, res) => {
  const locationId = String(req.query.locationId || ''); const products = state.products.filter((p) => p.active); const stock = (p) => locationId ? Number(state.balances[`${p.id}|${locationId}`] || 0) : totalFor(p.id);
  const low = products.filter((p) => stock(p) <= p.reorderPoint);
  const days = Array.from({ length: 7 }, (_, index) => { const date = new Date(); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - (6 - index)); const key = date.toISOString().slice(0, 10); return { date: key, label: date.toLocaleDateString('en-US', { weekday: 'short' }), received: 0, delivered: 0 }; });
  const trend = Object.fromEntries(days.map((day) => [day.date, day]));
  for (const move of state.ledger) { const day = trend[new Date(move.date).toISOString().slice(0, 10)]; if (!day || (locationId && move.locationId !== locationId)) continue; if (move.type === 'Receipt' && move.delta > 0) day.received += move.delta; if (move.type === 'Delivery' && move.delta < 0) day.delivered += Math.abs(move.delta); }
  res.json({ totalUnits: products.reduce((sum, p) => sum + stock(p), 0), productCount: products.length, lowStockCount: low.length, outOfStockCount: low.filter((p) => stock(p) === 0).length, pendingReceipts: state.documents.filter((d) => d.type === 'Receipt' && ['Waiting', 'Ready'].includes(d.state)).length, pendingDeliveries: state.documents.filter((d) => d.type === 'Delivery' && ['Waiting', 'Ready'].includes(d.state)).length, scheduledTransfers: state.documents.filter((d) => d.type === 'Internal' && ['Waiting', 'Ready'].includes(d.state)).length, lowStockItems: low.slice(0, 5).map((p) => ({ ...p, totalStock: stock(p) })), movementTrend: days });
});
app.get('/api/alerts/low-stock', (_req, res) => res.json({ data: state.products.filter((p) => totalFor(p.id) <= p.reorderPoint).map((p) => ({ ...p, totalStock: totalFor(p.id) })) }));
app.get('/api', (_req, res) => res.json({ name: 'StockSense API', version: '1.0.0' }));
app.use('/api', (_req, res) => fail(res, 404, 'NOT_FOUND', 'API route not found.'));
app.use((err, _req, res, _next) => { console.error(err); fail(res, 500, 'SERVER_ERROR', 'Something went wrong.'); });
module.exports = app;
