const crypto = require('node:crypto');
const { state } = require('./store');

const sessions = new Map();
const resets = new Map();
const hash = (password, salt = crypto.randomBytes(16).toString('hex')) => ({
  salt,
  digest: crypto.pbkdf2Sync(password, salt, 120000, 32, 'sha256').toString('hex'),
});
function makeToken(user) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { id: user.id, expiresAt: Date.now() + 7 * 86400000 });
  return token;
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) return res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Please sign in to continue.' } });
  req.user = state.users.find((user) => user.id === session.id);
  if (!req.user) return res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Please sign in to continue.' } });
  next();
}
module.exports = { hash, makeToken, auth, resets, sessions };
