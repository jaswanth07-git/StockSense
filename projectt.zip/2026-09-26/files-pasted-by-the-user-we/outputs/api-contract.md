# StockSense API contract

The implemented API contract is maintained with the runnable project at [StockSense/docs/api-contract.md](StockSense/docs/api-contract.md). It lists the routes, request/response shapes, document states, and stock validation semantics. The current implementation uses local JSON persistence; MySQL persistence is not connected yet.
